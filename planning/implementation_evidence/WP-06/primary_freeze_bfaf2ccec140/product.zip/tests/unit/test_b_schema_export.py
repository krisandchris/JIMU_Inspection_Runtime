"""Read-only CLI comparison, deterministic output and filesystem confinement."""

import ast
import hashlib
import os
import subprocess
import sys
from dataclasses import replace
from pathlib import Path
from types import ModuleType

import pytest

from scripts import generate_schemas as exporter

ROOT = Path(__file__).parents[2]
SCRIPT = ROOT / "scripts/generate_schemas.py"


@pytest.fixture(scope="module")
def rendered() -> dict[str, bytes]:
    return exporter.render_exports()


def tree(directory: Path) -> dict[str, tuple[str, int, int]]:
    if not directory.exists():
        return {}
    result = {}
    for path in directory.rglob("*"):
        stat = path.lstat()
        digest = (
            os.readlink(path)
            if path.is_symlink()
            else hashlib.sha256(path.read_bytes()).hexdigest()
            if path.is_file()
            else "directory"
        )
        result[str(path.relative_to(directory))] = (
            digest,
            stat.st_mtime_ns,
            stat.st_size,
        )
    return result


def seed(output: Path, rendered: dict[str, bytes]) -> None:
    output.mkdir()
    for name, encoded in rendered.items():
        (output / name).write_bytes(encoded)


def imported_source_tree(root: Path = ROOT) -> dict[str, tuple[str, int, int] | None]:
    """Watch actual imported source/cache paths, excluding unrelated active writers."""
    result: dict[str, tuple[str, int, int] | None] = {}
    for module in tuple(sys.modules.values()):
        source = getattr(module, "__file__", None)
        if not isinstance(source, str) or not Path(source).is_relative_to(root):
            continue
        for filename in (source, getattr(module, "__cached__", None)):
            if not isinstance(filename, str):
                continue
            path = Path(filename)
            if not path.is_relative_to(root):
                continue
            key = str(path.relative_to(root))
            if not path.exists():
                result[key] = None
            else:
                stat = path.stat()
                result[key] = (
                    hashlib.sha256(path.read_bytes()).hexdigest(),
                    stat.st_mtime_ns,
                    stat.st_size,
                )
            if filename != source:
                parent = path.parent
                # Directory presence catches an empty new cache directory, but
                # unrelated writers' entries must not change this shared mtime.
                result[str(parent.relative_to(root)) + "/"] = (
                    ("directory", 0, 0) if parent.exists() else None
                )
    return result


def test_cache_monitor_detects_previously_absent_directory_and_tagged_pyc(
    tmp_path: Path, monkeypatch: pytest.MonkeyPatch
) -> None:
    source = tmp_path / "probe.py"
    source.write_text("value = 1\n")
    cache = tmp_path / "__pycache__" / "probe.cpython-312.pyc"
    probe = ModuleType("e1_cache_probe")
    probe.__file__ = str(source)
    probe.__cached__ = str(cache)
    monkeypatch.setitem(sys.modules, "e1_cache_probe", probe)
    before = imported_source_tree(tmp_path)
    assert before["__pycache__/"] is None
    assert before["__pycache__/probe.cpython-312.pyc"] is None
    cache.parent.mkdir()
    with_directory = imported_source_tree(tmp_path)
    assert with_directory != before
    cache.write_bytes(b"synthetic bytecode")
    assert imported_source_tree(tmp_path) != with_directory


def test_repeated_generation_is_identical(rendered: dict[str, bytes]) -> None:
    assert exporter.render_exports() == rendered


@pytest.mark.parametrize("change", ["valid", "missing", "stale", "additional"])
def test_cli_check_is_read_only_and_detects_mismatch(
    tmp_path: Path, rendered: dict[str, bytes], change: str
) -> None:
    output = tmp_path / "generated"
    seed(output, rendered)
    chosen = next(name for name in rendered if name != "index.json")
    if change == "missing":
        (output / chosen).unlink()
    elif change == "stale":
        (output / chosen).write_bytes(b"{}\n")
    elif change == "additional":
        (output / "unknown.txt").write_text("preserve")
    before = tree(tmp_path)
    sources = tree(ROOT / "src")
    source_imports = imported_source_tree()
    completed = subprocess.run(
        [sys.executable, str(SCRIPT), "--check", "--output", str(output)],
        cwd=tmp_path,
        capture_output=True,
        text=True,
    )
    assert completed.returncode == (0 if change == "valid" else 1), completed.stderr
    assert tree(tmp_path) == before
    assert (
        tree(ROOT / "src") == sources
    )  # Run only after all source writers are quiescent.
    assert (
        imported_source_tree() == source_imports
    )  # Also watches absent cache/tagged-pyc paths.


def test_check_missing_directory_creates_nothing(tmp_path: Path) -> None:
    before = tree(tmp_path)
    completed = subprocess.run(
        [sys.executable, str(SCRIPT), "--check", "--output", str(tmp_path / "missing")],
        cwd=tmp_path,
        capture_output=True,
        text=True,
    )
    assert completed.returncode == 1
    assert tree(tmp_path) == before


def test_bootstrap_installs_no_bytecode_before_all_source_imports() -> None:
    module = ast.parse(SCRIPT.read_text())
    assignment = next(
        i
        for i, node in enumerate(module.body)
        if isinstance(node, ast.Assign)
        and any(
            isinstance(target, ast.Attribute)
            and isinstance(target.value, ast.Name)
            and target.value.id == "sys"
            and target.attr == "dont_write_bytecode"
            for target in node.targets
        )
    )
    bootstrap = next(
        i
        for i, node in enumerate(module.body)
        if isinstance(node, ast.FunctionDef) and node.name == "_bootstrap"
    )
    assert assignment < bootstrap
    assert not any(
        isinstance(node, ast.ImportFrom)
        and (node.module or "").startswith("jimu_runtime")
        for node in module.body
    )
    assert sys.dont_write_bytecode is True


@pytest.mark.parametrize(
    "filename",
    [
        "../escape.schema.json",
        "a/b.schema.json",
        "/tmp/escape.schema.json",
        "index.json",
        "x.schema.json\n",
    ],
)
def test_invalid_filenames_reject_before_generation(filename: str) -> None:
    with pytest.raises(ValueError, match="basename"):
        exporter.render_exports((replace(exporter.INVENTORY[0], filename=filename),))


def test_inventory_source_and_filename_collisions_are_explicit() -> None:
    first, second = exporter.INVENTORY[:2]
    with pytest.raises(ValueError, match="Duplicate"):
        exporter.render_exports((first, replace(second, filename=first.filename)))
    with pytest.raises(ValueError, match="Duplicate"):
        exporter.render_exports((first, replace(first, filename="other.schema.json")))


def test_source_module_must_originate_from_this_repository(tmp_path: Path) -> None:
    module = ModuleType("jimu_runtime.domain.primitives")
    module.__file__ = str(tmp_path / "primitives.py")
    with pytest.raises(ValueError, match="repository"):
        exporter.render_exports((replace(exporter.INVENTORY[0], module=module),))


def test_output_traversal_rejects_without_creating_directories(tmp_path: Path) -> None:
    before = tree(tmp_path)
    with pytest.raises(ValueError, match="traversal"):
        exporter.export_schemas(tmp_path / ".." / "escape", check=True)
    assert tree(tmp_path) == before


@pytest.mark.parametrize("kind", ["directory", "ancestor", "file", "unknown", "broken"])
def test_symlinks_never_followed(
    tmp_path: Path, rendered: dict[str, bytes], kind: str
) -> None:
    outside = tmp_path / "outside"
    outside.mkdir()
    (outside / "sentinel").write_text("preserve")
    output = tmp_path / "generated"
    if kind == "directory":
        output.symlink_to(outside, target_is_directory=True)
    elif kind == "ancestor":
        ancestor = tmp_path / "linked-parent"
        ancestor.symlink_to(outside, target_is_directory=True)
        output = ancestor / "generated"
    else:
        seed(output, rendered)
        if kind == "file":
            chosen = next(name for name in rendered if name != "index.json")
            (output / chosen).unlink()
            (output / chosen).symlink_to(outside / "sentinel")
        else:
            (output / "linked").symlink_to(
                outside / "missing" if kind == "broken" else outside / "sentinel"
            )
    before = tree(outside)
    with pytest.raises(ValueError, match="symlink"):
        exporter.export_schemas(output, check=True)
    assert tree(outside) == before


@pytest.mark.parametrize(
    "reference",
    [
        "https://example.invalid/schema",
        "#/$defs/missing",
        "#anchor",
        "#/$defs/bad~2escape",
    ],
)
def test_invalid_refs_reject_offline(reference: str) -> None:
    with pytest.raises(ValueError):
        exporter.validate_document({"$ref": reference})


def test_local_pointer_escaped_names_resolve_without_network() -> None:
    exporter.validate_document(
        {"$defs": {"with/slash~": {"type": "boolean"}}, "$ref": "#/$defs/with~1slash~0"}
    )


def test_unknown_entries_are_preserved_and_never_deleted(
    tmp_path: Path, rendered: dict[str, bytes]
) -> None:
    output = tmp_path / "generated"
    seed(output, rendered)
    (output / "extra").mkdir()
    before = tree(output)
    assert exporter.export_schemas(output)
    assert tree(output) == before


def test_new_contract_roots_are_monitored_by_readonly_cli_checks(
    rendered: dict[str, bytes],
) -> None:
    # The existing CLI matrix checks every emitted file, including these new roots.
    assert {
        "conditions.ConditionExpr.schema.json",
        "policies.PolicyArtifact.schema.json",
        "producers.ProducerCatalogue.schema.json",
        "validation.producer_authority_inputs.ProducerAuthorityValidationInput.schema.json",
        "validation.condition_inputs.ConditionReferenceContext.schema.json",
        "validation.definition_inputs.DefinitionValidationInput.schema.json",
    } <= rendered.keys()
