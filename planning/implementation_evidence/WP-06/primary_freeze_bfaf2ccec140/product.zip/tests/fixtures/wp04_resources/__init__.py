"""Isolated resource accounting fixtures."""
