"""Validate WP-01C fixtures against the export and WP-01B against its sealed bytes."""

import hashlib
import json
from pathlib import Path
from typing import Any

import pytest
from fixtures.wp01c.applicability.cases import wire_case
from fixtures.wp01c.nodes.cases import cases as node_cases
from jsonschema import Draft202012Validator, FormatChecker
from pydantic import TypeAdapter, ValidationError

from scripts import generate_schemas as exporter

_ROOT = Path(__file__).parents[2]
_FIXTURES = _ROOT / "tests/fixtures/wp01c"
_BASELINE = (
    _ROOT / "planning/implementation_evidence/WP-01B/execution_03/after_sha256.json"
)
_GENERATED = _ROOT / "schemas/generated"
_PERSISTED_ROLES = {"definition_root", "runtime_root"}
_PERSISTED_UNIONS = {
    "runtime.selection.QuestionSelectionRecord": (
        "AllDeclaredSelectionRecord",
        "ContextRuleSelectionRecord",
        "ModelAdvisorySelectionRecord",
        "FallbackSelectionRecord",
    ),
    "nodes.context.ContextBuildOutput": (
        "SuccessfulContextBuild",
        "FailedContextBuild",
    ),
    "nodes.discovery.DiscoveryOutput": (
        "DiscoveryAttemptOutput",
        "SkippedDiscoveryOutput",
    ),
    "nodes.envelopes.NodeOutputEnvelope": (
        "SucceededNodeOutput",
        "FailedNodeOutput",
        "CancelledNodeOutput",
    ),
    "runtime.replay.ReplayRun": ("ArtifactReplayRun", "InferenceReplayRun"),
}


def _read(relative_path: str) -> Any:
    return json.loads((_FIXTURES / relative_path).read_text())


def _examples() -> dict[str, dict[str, Any]]:
    release = _read("releases/release.json")
    execution = _read("executions/contracts.json")
    invocation = _read("invocations/contracts.json")
    _, applicability = wire_case("H01")
    nodes = node_cases()
    return {
        "rules.definitions.RuleDefinition": _read("rule_declarations/rule-valid.json"),
        "rules.definitions.RuleSetDefinition": _read(
            "rule_declarations/rule-set-valid.json"
        ),
        "definitions.geometry.GeometryResourceDefinition": _read(
            "geometry_replay/geometry-valid.json"
        ),
        "runtime.bundle_manifest.BundleManifest": _read(
            "releases/bundle_manifest.json"
        ),
        "runtime.bundle_manifest.ChecksumManifest": _read("releases/checksums.json"),
        "runtime.releases.AdmissionReceipt": release["admission_receipt"],
        "runtime.releases.ApprovalReceipt": release["approval_receipt"],
        "runtime.releases.ReleaseRecord": release,
        "runtime.releases.ActivationRecord": _read("releases/activation.json"),
        "runtime.intake.TaskSubmission": _read("intake/task-submission-valid.json"),
        "runtime.intake.AcceptedTask": _read("intake/accepted-task-valid.json"),
        "runtime.intake.ContextSnapshot": _read("intake/context-snapshot-valid.json"),
        "runtime.media.MediaAsset": _read("intake/media-asset-valid.json"),
        "runtime.evidence.EvidenceAsset": _read("intake/evidence-asset-valid.json"),
        "runtime.executions.ExecutionRecord": execution["execution"],
        "runtime.executions.NodeRun": execution["node"],
        "runtime.executions.Attempt": execution["attempt"],
        "runtime.executions.ExecutionEvent": execution["system_event"],
        "runtime.invocations.ModelInvocation": invocation["models"]["observation"],
        "runtime.selection.AllDeclaredSelectionRecord": invocation["selections"]["all"],
        "runtime.selection.ContextRuleSelectionRecord": invocation["selections"][
            "context"
        ],
        "runtime.selection.ModelAdvisorySelectionRecord": invocation["selections"][
            "shared"
        ],
        "runtime.selection.FallbackSelectionRecord": invocation["selections"][
            "fallback_context"
        ],
        "runtime.tool_executions.ToolExecution": invocation["tools"]["step"],
        "runtime.applicability.ProfileEligibilityEvaluation": applicability[
            "profile_eligibility"
        ],
        "runtime.applicability.RuleSetApplicabilityEvaluation": applicability[
            "rule_set_evaluations"
        ][0],
        "runtime.applicability.RuleApplicabilityEvaluation": applicability[
            "rule_evaluations"
        ][0],
        "runtime.applicability.ApplicabilityTrace": applicability["traces"][2],
        "runtime.applicability.UnresolvedObligation": applicability[
            "unresolved_obligations"
        ][0],
        "runtime.coverage.ExecutionCoverage": _read(
            "decisions/execution_coverage.json"
        ),
        "runtime.coverage.ProfileCoverage": _read("decisions/profile_coverage.json"),
        "runtime.decisions.CandidatePrediction": _read(
            "decisions/candidate_prediction.json"
        ),
        "runtime.decisions.DecisionRecord": _read("decisions/decision_record.json"),
        "runtime.perception.ObjectRecord": nodes["object_record"],
        "runtime.perception.GroundingRecord": nodes["grounding_record"],
        "runtime.observations.ObservationBatch": nodes["batch"],
        "nodes.context.ContextBuildInput": nodes["context_input"],
        "nodes.context.SuccessfulContextBuild": nodes["context_output"],
        "nodes.context.FailedContextBuild": nodes["context_failure"],
        "nodes.discovery.DiscoveryInput": nodes["discovery_input"],
        "nodes.discovery.DiscoveryProfileDiagnostic": nodes["discovery_diagnostic"],
        "nodes.discovery.DiscoveryAttemptOutput": nodes["discovery_output"],
        "nodes.discovery.SkippedDiscoveryOutput": nodes["skipped_discovery"],
        "nodes.grounding.GroundingInput": nodes["grounding_input"],
        "nodes.grounding.GroundingOutput": nodes["grounding_output"],
        "nodes.observation.ObservationInput": nodes["observation_input"],
        "nodes.tool_execution.ToolNodeInput": nodes["tool_input"],
        "nodes.tool_execution.ToolNodeOutput": nodes["tool_output"],
        "nodes.decision.DecisionInput": nodes["decision_input"],
        "nodes.decision.DecisionOutput": nodes["decision_output"],
        "nodes.envelopes.NodeInputEnvelope": nodes["input_envelope"],
        "nodes.envelopes.SucceededNodeOutput": nodes["output_envelope"],
        "nodes.envelopes.FailedNodeOutput": nodes["failed_envelope"],
        "nodes.envelopes.CancelledNodeOutput": nodes["cancelled_envelope"],
        "runtime.replay.ArtifactReplayRun": _read(
            "geometry_replay/artifact-replay-run-valid.json"
        ),
        "runtime.replay.InferenceReplayRun": _read(
            "geometry_replay/inference-replay-run-valid.json"
        ),
    }


@pytest.fixture(scope="module")
def rendered() -> dict[str, bytes]:
    return exporter.render_exports()


def test_published_b_schemas_keep_their_sealed_file_hashes(
    rendered: dict[str, bytes],
) -> None:
    sealed = json.loads(_BASELINE.read_text())["files"]
    baseline = {
        Path(path).name: digest
        for path, digest in sealed.items()
        if path.startswith("schemas/generated/") and path.endswith(".schema.json")
    }
    assert len(baseline) == 162
    assert set(baseline) == {entry.filename for entry in exporter.WP01B_INVENTORY}
    for name, digest in baseline.items():
        assert hashlib.sha256(rendered[name]).hexdigest() == digest, name
        assert hashlib.sha256((_GENERATED / name).read_bytes()).hexdigest() == digest, (
            name
        )


def test_c_index_roles_hashes_and_open_scope(rendered: dict[str, bytes]) -> None:
    index = json.loads(rendered["index.json"])
    assert index["status"] == "COMPLETE_WP01C_CONTRACTS"
    assert index["generation"]["dialect"] == exporter.DIALECT
    assert {"deterministic Rule evaluation", "Release and Bundle admission"} <= set(
        index["deferred_groups"]
    )
    entries = {item["filename"]: item for item in index["schemas"]}
    assert set(rendered) == entries.keys() | {"index.json"}
    assert len(entries) == len(exporter.INVENTORY)
    for entry in exporter.WP01C_INVENTORY:
        item = entries[entry.filename]
        assert item["source_symbol"] == entry.source_symbol
        assert item["role"] == entry.role
        assert item["sha256"] == hashlib.sha256(rendered[entry.filename]).hexdigest()
    assert (
        entries["runtime.applicability.ApplicabilityLevelTrace.schema.json"]["role"]
        == "named_union"
    )
    assert (
        entries["runtime.executions.ExecutionPins.schema.json"]["role"]
        == "runtime_component"
    )
    assert entries["runtime.executions.NodeId.schema.json"]["role"] == "foundation"
    assert (
        entries["runtime.replay.ArtifactReplayRequest.schema.json"]["role"]
        == "nonpersistent_input"
    )


@pytest.fixture(scope="module")
def examples() -> dict[str, dict[str, Any]]:
    return _examples()


def _source_name(entry: Any) -> str:
    return entry.source_symbol.removeprefix("jimu_runtime.domain.")


_C_PERSISTED = tuple(
    entry for entry in exporter.WP01C_INVENTORY if entry.role in _PERSISTED_ROLES
)


def test_every_c_persisted_root_has_a_registered_fixture(
    examples: dict[str, dict[str, Any]],
) -> None:
    assert {_source_name(entry) for entry in _C_PERSISTED} == examples.keys()


@pytest.mark.parametrize(
    "entry", _C_PERSISTED, ids=[_source_name(entry) for entry in _C_PERSISTED]
)
def test_c_root_export_accepts_valid_fixture_and_rejects_structural_invalids(
    entry: Any, rendered: dict[str, bytes], examples: dict[str, dict[str, Any]]
) -> None:
    raw = examples[_source_name(entry)]
    published = json.loads(rendered[entry.filename])
    assert published["additionalProperties"] is False
    assert "schema_version" in published["required"]
    validator = Draft202012Validator(published, format_checker=FormatChecker())
    adapter = TypeAdapter(getattr(entry.module, entry.symbol))
    _check_wire(raw, validator, adapter)


@pytest.mark.parametrize("source", _PERSISTED_UNIONS)
def test_c_persisted_union_dispatches_every_fixtured_branch(
    source: str, rendered: dict[str, bytes], examples: dict[str, dict[str, Any]]
) -> None:
    entry = next(
        item for item in exporter.WP01C_INVENTORY if _source_name(item) == source
    )
    assert entry.role == "named_union"
    published = json.loads(rendered[entry.filename])
    branches = _PERSISTED_UNIONS[source]
    assert len(published["oneOf"]) == len(branches)
    validator = Draft202012Validator(published, format_checker=FormatChecker())
    adapter = TypeAdapter(getattr(entry.module, entry.symbol))
    for branch in branches:
        _check_wire(
            examples[f"{source.rsplit('.', 1)[0]}.{branch}"], validator, adapter
        )


def _check_wire(
    raw: dict[str, Any], validator: Draft202012Validator, adapter: TypeAdapter[Any]
) -> None:
    validator.validate(raw)
    model = adapter.validate_json(json.dumps(raw))
    serialized = adapter.dump_json(model)
    validator.validate(json.loads(serialized))
    assert adapter.validate_json(serialized) == model
    without_version = {
        key: value for key, value in raw.items() if key != "schema_version"
    }
    for invalid in (without_version, {**raw, "invalid_extra_field": True}):
        assert not validator.is_valid(invalid)
        with pytest.raises(ValidationError):
            adapter.validate_json(json.dumps(invalid))
