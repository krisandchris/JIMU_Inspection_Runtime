"""Six-node data contracts."""
