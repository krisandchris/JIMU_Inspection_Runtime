"""Apply fenced artifacts and close one Execution with its shared Coverage ledger."""

from datetime import datetime

from sqlalchemy.ext.asyncio import AsyncConnection

from jimu_runtime.domain.enums import ExecutionStatus, NodeRunStatus, TaskStatus
from jimu_runtime.domain.nodes.context import SuccessfulContextBuild
from jimu_runtime.domain.nodes.envelopes import FailedNodeOutput, SucceededNodeOutput
from jimu_runtime.domain.runtime.authority import AuthoritativeResultSelection
from jimu_runtime.domain.runtime.evidence import EvidenceAsset
from jimu_runtime.domain.runtime.executions import Attempt, ContextSnapshotPin, NodeRun
from jimu_runtime.domain.runtime.facts import FactRecord
from jimu_runtime.domain.runtime.intake import IdempotencyScope
from jimu_runtime.domain.runtime.invocations import ModelInvocation
from jimu_runtime.domain.runtime.observations import ObservationBatch
from jimu_runtime.domain.runtime.perception import GroundingOutcome
from jimu_runtime.domain.runtime.tool_executions import ToolExecution
from jimu_runtime.domain.validation.runtime_authority import RuntimeAuthorityRecords
from jimu_runtime.workflow import repository as repo
from jimu_runtime.workflow.engine import DecisionDraft, plan_work
from jimu_runtime.workflow.jobs import StagedDecision
from jimu_runtime.workflow.mock_decision import finish_decision
from jimu_runtime.workflow.worker_coverage import (
    build_coverage_authority,
    finalize_execution,
)
from jimu_runtime.workflow.worker_nodes import NodeResult
from jimu_runtime.workflow.worker_records import (
    MESSAGE_KEY,
    ContextMessage,
    DecisionMessage,
    DiscoveryMessage,
    GroundingMessage,
    ObservationMessage,
    ToolMessage,
)
from jimu_runtime.workflow.worker_source import OpenExecution
from jimu_runtime.workflow.worker_state import (
    WorkerRecords,
    load_attempts,
    load_records,
)


async def persist_result(
    connection: AsyncConnection,
    scope: IdempotencyScope,
    locked: repo.LockedExecution,
    node: NodeRun,
    attempt: Attempt,
    outcome: SucceededNodeOutput | FailedNodeOutput,
    now: datetime,
    result: NodeResult,
) -> None:
    execution = locked.execution
    message = result.message
    env = message.input_envelope()
    if (
        message.output_envelope() != outcome
        or (env.execution_id, env.node_run_id, env.attempt_id)
        != (node.execution_id, node.node_run_id, attempt.attempt_id)
        or not {pin for pin in outcome.output_artifacts}
        <= {item.pin for item in result.artifacts}
        or len({item.ref for item in result.artifacts}) != len(result.artifacts)
    ):
        raise ValueError(
            "validated node result requires the exact fenced artifact manifest"
        )
    await repo.store_output(
        connection,
        scope,
        node.execution_id,
        node.node_run_id,
        attempt.attempt_id,
        output_key=MESSAGE_KEY,
        output_kind="worker_message",
        record=message,
    )
    for item in result.artifacts:
        await repo.store_output(
            connection,
            scope,
            node.execution_id,
            node.node_run_id,
            attempt.attempt_id,
            output_key=f"{item.ref.record_kind.value}.{item.ref.record_id}",
            output_kind=item.ref.record_kind.value,
            record=item.record,
        )
    pin = execution.context_snapshot
    if isinstance(message, ContextMessage) and isinstance(
        message.output, SuccessfulContextBuild
    ):
        pin = ContextSnapshotPin(
            snapshot_ref=message.output.context_snapshot_ref,
            snapshot_digest=message.output.context_snapshot_digest,
        )
    if pin != execution.context_snapshot or result.model_refs:
        following = execution.model_copy(
            update={
                "context_snapshot": pin,
                "model_invocation_refs": (
                    *execution.model_invocation_refs,
                    *result.model_refs,
                ),
            }
        )
        await repo.transition_execution(
            connection, scope, execution, following, now=now
        )


def _terminal(data: WorkerRecords) -> tuple[ExecutionStatus, TaskStatus]:
    failure = any(
        node.status is NodeRunStatus.FAILED for node in data.runs.values()
    ) or any(
        isinstance(message, DiscoveryMessage)
        and message.output.outcome == "partial"
        or isinstance(message, ObservationMessage)
        and message.batch.outcome == "partial"
        or isinstance(message, GroundingMessage)
        and any(
            record.outcome in (GroundingOutcome.PARTIAL, GroundingOutcome.FAILED)
            for record in message.records
        )
        for message in data.messages.values()
    )
    if not failure:
        return ExecutionStatus.COMPLETED, TaskStatus.COMPLETED
    if any(isinstance(message, DecisionMessage) for message in data.messages.values()):
        return ExecutionStatus.PARTIAL_FAILED, TaskStatus.PARTIAL_FAILED
    return ExecutionStatus.FAILED, TaskStatus.FAILED


async def finalize(
    connection: AsyncConnection,
    scope: IdempotencyScope,
    locked: repo.LockedExecution,
    staged: tuple[StagedDecision, ...],
    now: datetime,
    opened: OpenExecution,
) -> bool:
    eid = locked.execution.execution_id
    data = await load_records(connection, scope, locked)
    state = data.planner_state(opened)
    work = plan_work(state).coverage
    if not work.ready_to_finalize:
        return False
    stages = tuple(
        item.result()
        for item in data.messages.values()
        if isinstance(item, DecisionMessage)
    )
    if {item.draft for item in stages} != {
        DecisionDraft.model_validate_json(item.draft_json) for item in staged
    }:
        raise ValueError(
            "execution publication requires the exact fenced set of staged Decisions"
        )
    attempts = await load_attempts(connection, scope, data)
    sources = data.coverage_sources(attempts)
    gate = None if data.gate is None else data.gate.result()
    all_facts: list[FactRecord] = []
    authorities: list[AuthoritativeResultSelection] = []
    evidence: list[EvidenceAsset] = []
    invocations: list[ModelInvocation] = []
    observations: list[ObservationBatch] = []
    tool_executions: list[ToolExecution] = []
    for message in data.messages.values():
        if isinstance(message, (DiscoveryMessage, GroundingMessage)):
            invocations.extend(message.invocations)
        elif isinstance(message, ObservationMessage):
            all_facts.extend(message.facts)
            authorities.append(message.authority)
            evidence.extend(message.evidence)
            invocations.append(message.invocation)
            observations.append(message.batch)
        elif isinstance(message, ToolMessage):
            all_facts.extend(message.facts)
            authorities.extend(message.authorities)
            tool_executions.extend(message.executions)
        elif isinstance(message, DecisionMessage):
            evidence.extend(message.evidence)
            invocations.append(message.invocation)
    authority = None
    if gate is not None and (all_facts or authorities):
        records = RuntimeAuthorityRecords(
            execution=state.execution,
            release=opened.release,
            manifest=opened.resolved.files.manifest,
            eligibility=gate.evaluation,
            objects=sources.objects,
            node_runs=sources.node_runs,
            attempts=attempts,
            question_selections=sources.question_selections,
            observations=tuple(observations),
            tool_executions=tuple(tool_executions),
            model_invocations=tuple(invocations),
            execution_events=(),
            facts=tuple(all_facts),
            authority_selections=tuple(authorities),
        )
        authority = build_coverage_authority(opened.resolved, records)
    result = finalize_execution(
        state,
        work,
        scope=opened.synthetic,
        sources=sources,
        gate=gate,
        stages=stages,
        facts=tuple(all_facts),
        authorities=tuple(authorities),
        evidence=tuple(evidence),
        invocations=tuple(invocations),
        authority=authority,
        now=now,
    )
    if gate is not None:
        for stage in stages:
            decision_output = finish_decision(
                opened.synthetic, stage, result.coverage, gate
            )
            env = decision_output.envelope
            await repo.store_output(
                connection,
                scope,
                eid,
                env.node_run_id,
                env.attempt_id,
                output_key="worker.decision.final",
                output_kind="decision_output",
                record=decision_output,
            )
    await repo.store_finalization(connection, scope, eid, result)
    status, task_status = _terminal(data)
    execution = state.execution
    await repo.transition_execution(
        connection,
        scope,
        execution,
        execution.model_copy(update={"status": status, "ended_at": now}),
        now=now,
    )
    await repo.transition_task(
        connection,
        scope,
        eid,
        execution.task_id,
        locked.task_status,
        task_status,
        now=now,
        trace=execution.trace,
    )
    return True
