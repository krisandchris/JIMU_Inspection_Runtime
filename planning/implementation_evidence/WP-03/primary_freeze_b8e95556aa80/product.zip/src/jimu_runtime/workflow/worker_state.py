"""Rebuild workflow inputs and planner records from scoped PostgreSQL history."""

from dataclasses import dataclass, field

from pydantic import TypeAdapter
from sqlalchemy.ext.asyncio import AsyncConnection

from jimu_runtime.domain.definition_support import reference_identity
from jimu_runtime.domain.enums import NodeRunStatus
from jimu_runtime.domain.nodes.discovery import SkippedDiscoveryOutput
from jimu_runtime.domain.nodes.envelopes import FailedNodeOutput, NodeOutputEnvelope
from jimu_runtime.domain.runtime.executions import Attempt, NodeId, NodeRun
from jimu_runtime.domain.runtime.facts import NodeRunRef, ObjectRef
from jimu_runtime.domain.runtime.intake import IdempotencyScope
from jimu_runtime.domain.validation.coverage_sources import (
    CoverageSources,
    ObjectDecisionBlocker,
)
from jimu_runtime.workflow import repository as repo
from jimu_runtime.workflow.engine import BranchKey, BranchRun, PlannerState
from jimu_runtime.workflow.jobs import NODE_OUTPUT_KEY
from jimu_runtime.workflow.mock_support import K
from jimu_runtime.workflow.worker_nodes import BranchInputs
from jimu_runtime.workflow.worker_records import (
    GATE_KEY,
    MESSAGE_KEY,
    MESSAGE_NODES,
    NODE_MESSAGE,
    SKIP_KEY,
    ContextMessage,
    DecisionMessage,
    DiscoveryMessage,
    EligibilityMessage,
    GroundingMessage,
    NodeMessage,
    ObservationMessage,
    ToolMessage,
)
from jimu_runtime.workflow.worker_source import OpenExecution

_OUTPUT = TypeAdapter[NodeOutputEnvelope](NodeOutputEnvelope)


def branch_name(key: BranchKey) -> str:
    return "global" if key.object_id is None else f"object:{key.object_id}"


def _branch(encoded: str, node: NodeRun) -> BranchKey:
    if encoded == "global":
        return BranchKey(node.node_id)
    prefix = "object:"
    if not encoded.startswith(prefix) or not encoded[len(prefix) :]:
        raise ValueError("invalid persisted workflow branch name")
    return BranchKey(node.node_id, encoded[len(prefix) :])


@dataclass(slots=True)
class WorkerRecords:
    locked: repo.LockedExecution
    runs: dict[BranchKey, NodeRun] = field(default_factory=dict)
    messages: dict[BranchKey, NodeMessage] = field(default_factory=dict)
    gate: EligibilityMessage | None = None
    skipped_discovery: SkippedDiscoveryOutput | None = None

    def inputs(self, object_id: str | None = None) -> BranchInputs:
        context = self.messages.get(BranchKey(NodeId.N01))
        discovery = self.messages.get(BranchKey(NodeId.N02))
        grounding = self.messages.get(BranchKey(NodeId.N03))
        observation = self.messages.get(BranchKey(NodeId.N04, object_id))
        tool = self.messages.get(BranchKey(NodeId.N05, object_id))
        return BranchInputs(
            context if isinstance(context, ContextMessage) else None,
            self.gate,
            discovery if isinstance(discovery, DiscoveryMessage) else None,
            grounding if isinstance(grounding, GroundingMessage) else None,
            observation if isinstance(observation, ObservationMessage) else None,
            tool if isinstance(tool, ToolMessage) else None,
        )

    def planner_state(self, opened: OpenExecution) -> PlannerState:
        inputs = self.inputs()
        return PlannerState(
            self.locked.execution,
            opened.synthetic.pins.bundle_digest,
            opened.profiles,
            tuple(BranchRun(key, run) for key, run in self.runs.items()),
            None if inputs.context is None else inputs.context.output,
            None if self.gate is None else self.gate.evaluation,
            self.skipped_discovery
            if inputs.discovery is None
            else inputs.discovery.output,
            None if inputs.grounding is None else inputs.grounding.output,
            () if inputs.grounding is None else inputs.grounding.objects,
            tuple(
                item.draft
                for item in self.messages.values()
                if isinstance(item, DecisionMessage)
            ),
        )

    def coverage_sources(self, attempts: tuple[Attempt, ...]) -> CoverageSources:
        previous = self.inputs()
        context, discovery, grounding = (
            previous.context,
            previous.discovery,
            previous.grounding,
        )
        blockers = []
        for key, run in self.runs.items():
            if (
                key.node_id is NodeId.N06
                and key.object_id is not None
                and run.status
                in (
                    NodeRunStatus.BLOCKED,
                    NodeRunStatus.FAILED,
                    NodeRunStatus.CANCELLED,
                )
            ):
                blockers.append(
                    ObjectDecisionBlocker(
                        object_ref=ObjectRef(
                            record_kind=K.OBJECT, record_id=key.object_id
                        ),
                        node_run_ref=NodeRunRef(
                            record_kind=K.NODE_RUN, record_id=run.node_run_id
                        ),
                        attempt_ref=None
                        if not run.attempt_history
                        else run.attempt_history[-1].attempt_ref,
                    )
                )
        return CoverageSources(
            execution=self.locked.execution,
            context_output=None if context is None else context.output,
            context_snapshot=None if context is None else context.snapshot,
            discovery_output=self.skipped_discovery
            if discovery is None
            else discovery.output,
            discovery_input=None if discovery is None else discovery.inputs,
            question_selections=() if discovery is None else discovery.selections,
            grounding_records=() if grounding is None else grounding.records,
            objects=() if grounding is None else grounding.objects,
            node_runs=tuple(self.runs.values()),
            attempts=attempts,
            decision_blockers=tuple(blockers),
        )


async def _node_message(
    connection: AsyncConnection,
    scope: IdempotencyScope,
    state: repo.LockedExecution,
    node: NodeRun,
) -> NodeMessage | None:
    if not node.attempt_history or node.status not in (
        NodeRunStatus.SUCCEEDED,
        NodeRunStatus.FAILED,
    ):
        return None
    execution = state.execution
    eid, nid = execution.execution_id, node.node_run_id
    aid = node.attempt_history[-1].attempt_ref.record_id
    if node.status is NodeRunStatus.SUCCEEDED:
        output = await repo.read_authority(connection, scope, eid, nid, _OUTPUT)
        if output is None:
            raise ValueError("successful node requires its authoritative output")
    else:
        output = await repo.read_output(
            connection, scope, eid, nid, aid, NODE_OUTPUT_KEY, _OUTPUT
        )
        if output is None:
            return None
    message = await repo.read_output(
        connection, scope, eid, nid, aid, MESSAGE_KEY, NODE_MESSAGE
    )
    if (
        message is None
        and isinstance(output, FailedNodeOutput)
        and output.error.code.startswith("worker_provider_")
        and not output.output_artifacts
    ):
        return None
    if message is None or not isinstance(message, MESSAGE_NODES[node.node_id]):
        raise ValueError("node output requires a matching typed workflow message")
    env = message.input_envelope()
    if (
        output != message.output_envelope()
        or (output.node_run_id, output.attempt_id, output.node_id, output.status)
        != (nid, aid, node.node_id, node.status)
        or (
            env.task_id,
            env.execution_id,
            env.release_id,
            env.bundle_digest,
            reference_identity(env.node_config_ref),
            env.trace,
        )
        != (
            execution.task_id,
            eid,
            execution.pins.release_id,
            execution.pins.bundle_digest,
            reference_identity(node.config_ref),
            node.trace,
        )
        or node.node_id is not NodeId.N01
        and tuple(pin.stable_json() for pin in env.upstream_artifacts)
        != tuple(pin.stable_json() for pin in node.upstream_inputs)
    ):
        raise ValueError(
            "workflow message does not match the exact selected execution, attempt and inputs"
        )
    return message


async def load_records(
    connection: AsyncConnection,
    scope: IdempotencyScope,
    locked: repo.LockedExecution,
) -> WorkerRecords:
    eid = locked.execution.execution_id
    data = WorkerRecords(locked)
    for name, node in await repo.list_branches(connection, scope, eid):
        key = _branch(name, node)
        data.runs[key] = node
        message = await _node_message(connection, scope, locked, node)
        if message is not None:
            data.messages[key] = message
        if node.node_id is NodeId.N01 and node.status is NodeRunStatus.SUCCEEDED:
            data.gate = await repo.read_engine_output(
                connection, scope, eid, node.node_run_id, GATE_KEY, EligibilityMessage
            )
        if node.node_id is NodeId.N02 and node.status is NodeRunStatus.SKIPPED:
            data.skipped_discovery = await repo.read_engine_output(
                connection,
                scope,
                eid,
                node.node_run_id,
                SKIP_KEY,
                SkippedDiscoveryOutput,
            )
    return data


async def load_attempts(
    connection: AsyncConnection,
    scope: IdempotencyScope,
    data: WorkerRecords,
) -> tuple[Attempt, ...]:
    attempts = []
    for node in data.runs.values():
        for link in node.attempt_history:
            stored = await repo.get_attempt(
                connection,
                scope,
                node.execution_id,
                node.node_run_id,
                link.attempt_ref.record_id,
            )
            if (
                stored is None
                or not stored.belongs_to_node(node)
                or stored.attempt_number != link.attempt_number
            ):
                raise ValueError("workflow requires every referenced durable Attempt")
            attempts.append(stored)
    return tuple(attempts)
