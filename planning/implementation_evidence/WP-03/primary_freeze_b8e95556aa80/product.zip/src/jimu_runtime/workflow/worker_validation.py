"""Validate outputs from a worker node port before granting persistence authority."""

from jimu_runtime.domain.definitions.capabilities import (
    ProfileDefinition,
    QuestionDefinition,
)
from jimu_runtime.domain.definitions.tools import ToolPlanDefinition
from jimu_runtime.domain.enums import NodeRunStatus
from jimu_runtime.domain.nodes.context import SuccessfulContextBuild
from jimu_runtime.domain.runtime.executions import Attempt, NodeId, NodeRun
from jimu_runtime.domain.runtime.facts import ModelInvocationRef
from jimu_runtime.workflow.engine import BranchKey
from jimu_runtime.workflow.mock_decision import mandatory_paths
from jimu_runtime.workflow.mock_facts import prepare_observation
from jimu_runtime.workflow.mock_support import K, artifact
from jimu_runtime.workflow.worker_nodes import BranchInputs, NodeResult
from jimu_runtime.workflow.worker_records import (
    MESSAGE_NODES,
    NODE_MESSAGE,
    ContextMessage,
    DecisionMessage,
    DiscoveryMessage,
    GroundingMessage,
    ObservationMessage,
    ToolMessage,
)
from jimu_runtime.workflow.worker_source import OpenExecution


def check_result(
    opened: OpenExecution,
    previous: BranchInputs,
    branch: BranchKey,
    node: NodeRun,
    attempt: Attempt,
    result: NodeResult,
) -> NodeResult:
    message = NODE_MESSAGE.validate_json(result.message.model_dump_json())
    env, output = message.input_envelope(), message.output_envelope()
    scope = opened.synthetic
    wanted_upstream = (
        (artifact(K.TASK, scope.task.task_id, scope.task).pin,)
        if node.node_id is NodeId.N01
        else node.upstream_inputs
    )
    if (
        not isinstance(message, MESSAGE_NODES[node.node_id])
        or not attempt.belongs_to_node(node)
        or (
            env.execution_id,
            env.node_run_id,
            env.attempt_id,
            env.trace,
            output.started_at,
        )
        != (
            node.execution_id,
            node.node_run_id,
            attempt.attempt_id,
            node.trace,
            attempt.started_at,
        )
        or tuple(pin.stable_json() for pin in env.upstream_artifacts)
        != tuple(pin.stable_json() for pin in wanted_upstream)
    ):
        raise ValueError("node reply must belong to the exact claimed invocation")
    assert attempt.started_at is not None
    scope.check_call(env, node.node_id, attempt.started_at)

    if isinstance(message, ContextMessage):
        message.output.check_invocation(message.inputs)
        if (
            isinstance(message.output, SuccessfulContextBuild)
            and message.snapshot is not None
        ):
            message.output.check_snapshot(message.inputs, message.snapshot)
        elif (
            isinstance(message.output, SuccessfulContextBuild)
            or message.snapshot is not None
        ):
            raise ValueError(
                "successful context alone may publish its validated snapshot"
            )
        if (
            message.inputs.accepted_task != scope.task
            or message.inputs.media_asset != scope.media
            or message.inputs.device_ref != opened.source.device
            or message.inputs.camera_ref != opened.source.camera
            or message.inputs.region_ref != opened.region_ref
        ):
            raise ValueError(
                "context reply must retain the verified Task and source registry"
            )
    elif isinstance(message, DiscoveryMessage):
        if previous.gate is None:
            raise ValueError("discovery must have a durable eligibility gate")
        message.inputs.check_gate(previous.gate.evaluation)
        message.inputs.check_profiles(
            tuple(
                scope.resolve(ref, ProfileDefinition)
                for ref in message.inputs.eligible_profiles
            )
        )
        message.output.check_records(
            message.inputs, message.selections, message.invocations
        )
        message.result()
    elif isinstance(message, GroundingMessage):
        if previous.discovery is None:
            raise ValueError("grounding requires complete discovery inputs")
        message.inputs.check_discovery(previous.discovery.output)
        message.output.check_records(
            message.inputs,
            message.records,
            message.objects,
            previous.discovery.selections,
            message.invocations,
            tuple(
                scope.resolve(item.hit.profile_ref, ProfileDefinition)
                for item in message.inputs.profiles
            ),
        )
    else:
        obj = previous.object_record(branch)
        profile = scope.resolve(obj.profile_ref, ProfileDefinition)
        inputs = (
            message.draft.inputs
            if isinstance(message, DecisionMessage)
            else message.inputs
        )
        if inputs.object_record != obj:
            raise ValueError("node reply must use the scoped durable Object")
        if isinstance(message, ObservationMessage):
            if previous.discovery is None:
                raise ValueError("observation needs its durable Question selection")
            (selection,) = tuple(
                item
                for item in previous.discovery.selections
                if item.selection_id == obj.question_selection_ref.record_id
            )
            message.inputs.check_configuration(
                obj.profile_ref,
                profile,
                selection,
                tuple(
                    (ref, scope.resolve(ref, QuestionDefinition))
                    for ref in obj.effective_question_refs
                ),
            )
            message.inputs.check_batch(message.batch, (message.invocation,), None)
            expected, evidence = prepare_observation(
                scope, env, obj, previous.snapshot(), attempt.started_at
            )
            if message.inputs != expected or message.evidence != tuple(
                item.record for item in evidence
            ):
                raise ValueError(
                    "joint observation must persist the selected synthetic request evidence"
                )
            if (
                output.status is not NodeRunStatus.SUCCEEDED
                or message.authority.selected_result_ref != message.batch.batch_ref
                or message.authority.selected_attempt_id != attempt.attempt_id
                or {
                    (ref.record_kind, ref.record_id)
                    for ref in message.authority.selected_fact_refs
                }
                != {(K.FACT, fact.fact_id) for fact in message.facts}
            ):
                raise ValueError(
                    "joint observation selection must name its exact successful result and Facts"
                )
        elif isinstance(message, ToolMessage):
            plan = scope.resolve(message.inputs.tool_plan_ref, ToolPlanDefinition)
            message.inputs.check_observation_facts(plan, (), None)
            message.output.check_steps(
                message.inputs, profile, plan, message.executions, message.facts
            )
        elif isinstance(message, DecisionMessage):
            if previous.gate is None:
                raise ValueError(
                    "Decision requires the durable Profile eligibility scope"
                )
            message.draft.inputs.check_gate(previous.gate.evaluation)
            message.draft.inputs.check_mandatory_scope(mandatory_paths(scope, obj))

    if not {pin for pin in output.output_artifacts} <= {
        item.pin for item in result.artifacts
    }:
        raise ValueError("node result is missing one or more pinned output artifacts")
    actual_refs = tuple(
        ModelInvocationRef(record_kind=K.MODEL_INVOCATION, record_id=item.ref.record_id)
        for item in result.artifacts
        if item.ref.record_kind is K.MODEL_INVOCATION
    )
    if actual_refs != result.model_refs:
        raise ValueError("model invocation index must account for the actual artifacts")
    return NodeResult(message, result.artifacts, result.model_refs)
