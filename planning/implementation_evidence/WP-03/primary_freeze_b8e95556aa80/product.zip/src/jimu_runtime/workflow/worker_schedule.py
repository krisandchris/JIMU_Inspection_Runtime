"""Persist deterministic branch transitions and successors in the caller's transaction."""

from datetime import datetime

from sqlalchemy.ext.asyncio import AsyncConnection

from jimu_runtime.bundle.integrity import sha256_digest
from jimu_runtime.domain.enums import NodeRunStatus
from jimu_runtime.domain.nodes.context import SuccessfulContextBuild
from jimu_runtime.domain.runtime.executions import (
    LifecycleReason,
    NodeId,
    NodeRun,
    PinnedRuntimeInput,
)
from jimu_runtime.domain.runtime.intake import IdempotencyScope
from jimu_runtime.domain.validation.transitions import NodeTransitionGuard
from jimu_runtime.workflow import repository as repo
from jimu_runtime.workflow.engine import BranchKey, ReadyWork, UninvokedWork, plan_work
from jimu_runtime.workflow.mock_context import build_gate, snapshot_artifact
from jimu_runtime.workflow.mock_perception import skipped_discovery
from jimu_runtime.workflow.mock_support import (
    VERSION,
    K,
    SyntheticArtifact,
    artifact,
    synthetic_id,
)
from jimu_runtime.workflow.worker_nodes import authority_artifact, fact_artifact
from jimu_runtime.workflow.worker_records import GATE_KEY, SKIP_KEY, EligibilityMessage
from jimu_runtime.workflow.worker_source import OpenExecution
from jimu_runtime.workflow.worker_state import WorkerRecords, branch_name, load_records


def _gate_artifact(data: WorkerRecords) -> SyntheticArtifact:
    if data.gate is None:
        raise ValueError("workflow requires the selected eligibility result")
    value = data.gate.evaluation
    return artifact(K.PROFILE_ELIGIBILITY_EVALUATION, value.evaluation_id, value)


def _inputs(data: WorkerRecords, work: ReadyWork) -> tuple[PinnedRuntimeInput, ...]:
    key = work.key
    previous = data.inputs(key.object_id)
    if key.node_id is NodeId.N02:
        return (snapshot_artifact(previous.snapshot()).pin, _gate_artifact(data).pin)
    if key.node_id is NodeId.N03 and previous.discovery is not None:
        return previous.discovery.output.envelope.output_artifacts
    if key.object_id is not None:
        obj = previous.object_record(key)
        refs: list[PinnedRuntimeInput] = [
            artifact(K.OBJECT, obj.object_id, obj).pin,
            snapshot_artifact(previous.snapshot()).pin,
        ]
        if key.node_id is NodeId.N04 and previous.discovery is not None:
            (selection,) = tuple(
                item
                for item in previous.discovery.selections
                if item.selection_id == obj.question_selection_ref.record_id
            )
            refs.append(
                artifact(
                    K.QUESTION_SELECTION_RECORD, selection.selection_id, selection
                ).pin
            )
        if key.node_id is NodeId.N06:
            refs.append(_gate_artifact(data).pin)
            facts, authorities = previous.selected_facts()
            refs.extend(fact_artifact(fact).pin for fact in facts)
            refs.extend(authority_artifact(selection).pin for selection in authorities)
        return tuple(refs)
    raise ValueError("successor requires its exact durable predecessor records")


def _prerequisites(key: BranchKey) -> tuple[BranchKey, ...]:
    if key.node_id is NodeId.N02:
        return (BranchKey(NodeId.N01),)
    if key.node_id is NodeId.N03:
        return (BranchKey(NodeId.N02),)
    if key.node_id is NodeId.N04:
        return (BranchKey(NodeId.N03),)
    if key.node_id is NodeId.N05:
        return (BranchKey(NodeId.N04, key.object_id),)
    if key.node_id is NodeId.N06:
        return (
            BranchKey(NodeId.N04, key.object_id),
            BranchKey(NodeId.N05, key.object_id),
        )
    raise ValueError("the root comes from durable intake")


async def _create(
    connection: AsyncConnection,
    scope: IdempotencyScope,
    data: WorkerRecords,
    key: BranchKey,
    now: datetime,
    upstream: tuple[PinnedRuntimeInput, ...],
) -> NodeRun:
    execution = data.locked.execution
    name = branch_name(key)
    identity = (execution.execution_id, key.node_id.value, name)
    digest = sha256_digest(
        synthetic_id(
            "node-input",
            data.locked.execution_policy_ref.stable_json(),
            execution.pins.input_digest,
            *identity,
            *(pin.stable_json() for pin in upstream),
        ).encode()
    )
    pending = NodeRun(
        schema_version=VERSION,
        node_run_id=synthetic_id("node", *identity),
        execution_id=execution.execution_id,
        node_id=key.node_id,
        trace=execution.trace,
        config_ref=data.locked.execution_policy_ref,
        upstream_inputs=upstream,
        input_digest=digest,
        status=NodeRunStatus.PENDING,
        created_at=now,
        attempt_history=(),
        output_refs=(),
    )
    return await repo.insert_node(
        connection, scope, execution.execution_id, pending, branch_key=name
    )


async def _ready(
    connection: AsyncConnection,
    scope: IdempotencyScope,
    data: WorkerRecords,
    work: ReadyWork,
    now: datetime,
) -> None:
    pending = await _create(connection, scope, data, work.key, now, _inputs(data, work))
    for key in _prerequisites(work.key):
        await repo.link_successor(
            connection,
            scope,
            pending.execution_id,
            data.runs[key].node_run_id,
            pending.node_run_id,
        )
    ready = NodeRun.model_validate(
        pending.model_copy(update={"status": NodeRunStatus.READY})
    )
    await repo.transition_node(
        connection,
        scope,
        pending.execution_id,
        pending,
        ready,
        now=now,
        guard=NodeTransitionGuard.PREREQUISITES_AVAILABLE,
    )
    await repo.insert_job(
        connection,
        scope,
        pending.execution_id,
        pending.node_run_id,
        repo.NewJob(
            job_id=f"job.{pending.node_run_id}",
            ready_at=now,
            budget=data.locked.scheduling_limits.for_node(pending.node_id),
        ),
    )


async def _uninvoked(
    connection: AsyncConnection,
    scope: IdempotencyScope,
    data: WorkerRecords,
    opened: OpenExecution,
    work: UninvokedWork,
    now: datetime,
) -> None:
    pending = await _create(connection, scope, data, work.key, now, ())
    if work.blocker_node_run_ref is not None:
        await repo.link_successor(
            connection,
            scope,
            pending.execution_id,
            work.blocker_node_run_ref.record_id,
            pending.node_run_id,
        )
    terminal = NodeRun.model_validate(
        pending.model_copy(
            update={
                "status": work.status,
                "reason": LifecycleReason(code=work.reason_code),
                "ended_at": now,
            }
        )
    )
    if work.key.node_id is NodeId.N02 and work.status is NodeRunStatus.SKIPPED:
        if data.gate is None:
            raise ValueError("N02 can only skip on an authoritative empty Profile gate")
        skip = skipped_discovery(
            opened.synthetic, data.gate.evaluation, pending.node_run_id
        )
        await repo.store_engine_output(
            connection,
            scope,
            pending.execution_id,
            pending.node_run_id,
            output_key=SKIP_KEY,
            output_kind="skipped_discovery",
            record=skip,
        )
    guard = (
        NodeTransitionGuard.DETERMINISTIC_SKIP
        if work.status is NodeRunStatus.SKIPPED
        else NodeTransitionGuard.PREREQUISITE_UNAVAILABLE
    )
    await repo.transition_node(
        connection, scope, pending.execution_id, pending, terminal, now=now, guard=guard
    )


async def schedule_after_terminal(
    connection: AsyncConnection,
    scope: IdempotencyScope,
    opened: OpenExecution,
    execution_id: str,
    now: datetime,
) -> None:
    locked = await repo.get_execution(connection, scope, execution_id)
    if locked is None:
        raise ValueError("terminal callback requires an Execution")
    if locked.cancel_requested_at is not None:
        return
    data = await load_records(connection, scope, locked)
    plan = plan_work(data.planner_state(opened))
    if plan.eligibility is not None:
        previous = data.inputs()
        context = previous.context
        if context is None or not isinstance(context.output, SuccessfulContextBuild):
            raise ValueError("Pre-N02 requires the selected successful ContextSnapshot")
        gate = build_gate(
            opened.synthetic, context.inputs, context.output, previous.snapshot(), now
        )
        data.gate = EligibilityMessage(
            schema_version=VERSION,
            evaluation=gate.evaluation,
            traces=gate.traces,
            scope=gate.scope,
        )
        await repo.store_engine_output(
            connection,
            scope,
            execution_id,
            context.output.envelope.node_run_id,
            output_key=GATE_KEY,
            output_kind="profile_eligibility",
            record=data.gate,
        )
        plan = plan_work(data.planner_state(opened))
    if plan.uninvoked:
        # Empty eligibility creates N02 first; materialize its output before
        # asking the planner for the remaining attempt-free branches.
        for work in plan.uninvoked:
            await _uninvoked(connection, scope, data, opened, work, now)
        data = await load_records(connection, scope, locked)
        plan = plan_work(data.planner_state(opened))
        for work in plan.uninvoked:
            await _uninvoked(connection, scope, data, opened, work, now)
    for ready in plan.ready:
        await _ready(connection, scope, data, ready, now)
