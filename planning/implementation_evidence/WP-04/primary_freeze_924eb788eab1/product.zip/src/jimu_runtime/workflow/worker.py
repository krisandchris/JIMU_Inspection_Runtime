"""Public durable worker entry point for the six-node workflow."""

from asyncio import Event, TaskGroup, to_thread, wait_for
from collections.abc import Awaitable, Callable
from dataclasses import dataclass
from datetime import datetime, timedelta
from enum import Enum
from typing import Literal

from sqlalchemy import text
from sqlalchemy.ext.asyncio import AsyncConnection, AsyncEngine

from jimu_runtime.bundle.archive import BundleLimits
from jimu_runtime.bundle.releases import ReleaseManager
from jimu_runtime.bundle.store import LocalBundleStore, StoreBusy
from jimu_runtime.domain.base import ContractModel
from jimu_runtime.domain.enums import ExecutionStatus, NodeRunStatus
from jimu_runtime.domain.nodes.envelopes import (
    FailedNodeOutput,
    NodeError,
    SucceededNodeOutput,
)
from jimu_runtime.domain.runtime.executions import (
    Attempt,
    ExecutionRecord,
    NodeId,
    NodeRun,
)
from jimu_runtime.domain.runtime.intake import IdempotencyScope
from jimu_runtime.domain.runtime.invocations import ModelInvocation
from jimu_runtime.tools.step_attempts import load_parent_step_history
from jimu_runtime.workflow import repository as repo
from jimu_runtime.workflow.engine import BranchKey, ExecutionFinalization
from jimu_runtime.workflow.intake import IntakeAuthorizationError, IntakeHostUnavailable
from jimu_runtime.workflow.jobs import (
    CompletionDisposition,
    DurableJobs,
    JobClaim,
    ResponseEvidence,
    StagedDecision,
)
from jimu_runtime.workflow.mock_support import VERSION, synthetic_id
from jimu_runtime.workflow.pins import ExecutionPinError
from jimu_runtime.workflow.scheduling import validated_milliseconds
from jimu_runtime.workflow.worker_capabilities import read_historical_capabilities
from jimu_runtime.workflow.worker_completion import finalize, persist_result
from jimu_runtime.workflow.worker_nodes import (
    BranchInputs,
    NodeResult,
    failed_discovery,
    invoke,
)
from jimu_runtime.workflow.worker_poll import runnable_executions
from jimu_runtime.workflow.worker_records import DecisionMessage, ToolMessage
from jimu_runtime.workflow.worker_schedule import schedule_after_terminal
from jimu_runtime.workflow.worker_source import (
    OpenExecution,
    WorkerHost,
    open_execution,
)
from jimu_runtime.workflow.worker_state import load_records
from jimu_runtime.workflow.worker_validation import check_result

_ACTIVE = frozenset((ExecutionStatus.INITIALIZED, ExecutionStatus.RUNNING))
type NodeInvoker = Callable[
    [OpenExecution, BranchInputs, BranchKey, NodeRun, Attempt], Awaitable[NodeResult]
]

type AttemptCheckpoint = Callable[[JobClaim, Attempt], Awaitable[None]]


@dataclass(frozen=True, slots=True)
class ClaimedNode:
    """An actually started NodeRun and its inputs, available outside the locks."""

    claim: JobClaim
    attempt: Attempt
    node: NodeRun
    branch: BranchKey
    opened: OpenExecution
    previous: BranchInputs
    execution: ExecutionRecord
    deadline: datetime


type ClaimedNodeInvoker = Callable[[ClaimedNode], Awaitable[NodeResult]]


class WorkerStep(Enum):
    IDLE = "idle"
    APPLIED = "applied"
    STAGED = "staged"
    RETRY_SCHEDULED = "retry_scheduled"
    DUPLICATE = "duplicate"
    LATE_RECORDED = "late_recorded"
    LEASE_LOST = "lease_lost"
    FINALIZED = "finalized"
    CANCELLED = "cancelled"


class RetryableNodeFailure(RuntimeError):
    """A trusted adapter reported a known transient invocation failure."""

    def __init__(
        self, error_class: Literal["transport", "timeout", "resource"]
    ) -> None:
        self.error_class = error_class
        super().__init__(error_class)


class AdapterRejected(ValueError):
    """Trusted, stable diagnostic for an operation that cannot publish output."""

    def __init__(self, code: str) -> None:
        self.code = code
        super().__init__(code)


def _failed_node(node: NodeRun, attempt: Attempt, error: Exception) -> FailedNodeOutput:
    error_class: Literal["transport", "timeout", "resource", "validation", "internal"]
    if isinstance(error, RetryableNodeFailure):
        error_class = error.error_class
    elif isinstance(error, TimeoutError):
        error_class = "timeout"
    elif isinstance(error, ConnectionError):
        error_class = "transport"
    elif isinstance(error, ValueError):
        error_class = "validation"
    else:
        error_class = "internal"
    code = (
        error.code
        if isinstance(error, AdapterRejected)
        else "invalid_output"
        if error_class == "validation"
        else error_class
    )
    assert attempt.started_at is not None
    return FailedNodeOutput(
        schema_version=VERSION,
        node_id=node.node_id,
        node_run_id=node.node_run_id,
        attempt_id=attempt.attempt_id,
        trace=node.trace,
        output_artifacts=(),
        started_at=attempt.started_at,
        finished_at=attempt.started_at,
        duration_ms=0,
        status=NodeRunStatus.FAILED,
        error=NodeError(
            code=f"worker_provider_{code}",
            error_class=error_class,
            retryable=error_class in {"transport", "timeout", "resource"},
            message="Worker node adapter failed before producing a validated result.",
            validation_issues=(),
        ),
    )


class WorkerSourceError(ValueError):
    """A scoped Execution's historical inputs could not be opened."""

    def __init__(self, code: str, *, retryable: bool) -> None:
        self.code = code
        self.retryable = retryable
        super().__init__(code)


@dataclass(frozen=True, slots=True)
class PollIssue:
    execution_id: str
    code: str
    retryable: bool


@dataclass(frozen=True, slots=True)
class WorkerPoll:
    step: WorkerStep
    execution_id: str | None
    after_execution_id: str | None
    issues: tuple[PollIssue, ...]


def _response(
    result: NodeResult,
) -> tuple[ResponseEvidence | None, ContractModel | None]:
    if not result.artifacts:
        return None, None
    if isinstance(result.message, ToolMessage) and any(
        execution.node_run_ref.record_id != result.message.inputs.envelope.node_run_id
        for execution in result.message.executions
    ):
        # The step journal retains each physical receipt under its child claim.
        return None, None
    response = next(
        (item for item in result.artifacts if isinstance(item.record, ModelInvocation)),
        result.artifacts[0],
    )
    invocation = response.record
    env = result.message.input_envelope()
    return ResponseEvidence(
        schema_version=VERSION,
        execution_id=env.execution_id,
        attempt_id=env.attempt_id,
        response_key=synthetic_id(
            "response", result.message.input_envelope().attempt_id
        ),
        response=response.pin,
        external_request_id=invocation.provider_request_id
        if isinstance(invocation, ModelInvocation)
        else None,
    ), response.record


async def _synthetic_invocation(
    opened: OpenExecution,
    inputs: BranchInputs,
    key: BranchKey,
    node: NodeRun,
    attempt: Attempt,
) -> NodeResult:
    return await to_thread(invoke, opened, inputs, key, node, attempt)


async def _renew(
    jobs: DurableJobs, claim: JobClaim, lease_ms: int, stopped: Event
) -> None:
    interval = lease_ms / 3_000
    while not stopped.is_set():
        try:
            await wait_for(stopped.wait(), timeout=interval)
        except TimeoutError:
            renewed = await jobs.heartbeat(claim, lease_ms)
            if renewed is None:
                return
            claim = renewed


class WorkflowWorker:
    """Run one durable action for a host-authorized Task Execution.

    Run again with the same scope and Execution ID after service restart. Each
    call opens the original admitted Bundle, and reconstructs selected inputs
    from PostgreSQL. Multiple Worker instances can serve the same Execution.
    """

    def __init__(
        self,
        engine: AsyncEngine,
        release_manager: ReleaseManager,
        bundle_store: LocalBundleStore,
        *,
        host: WorkerHost,
        bundle_limits: BundleLimits,
        invoke_node: NodeInvoker = _synthetic_invocation,
        invoke_claimed_node: ClaimedNodeInvoker | None = None,
    ) -> None:
        if invoke_claimed_node is not None and invoke_node is not _synthetic_invocation:
            raise ValueError("choose one node adapter for this worker")
        self._engine = engine
        self._manager = release_manager
        self._store = bundle_store
        self._host = host
        self._limits = bundle_limits
        self._invoke_node = invoke_node
        self._invoke_claimed_node = invoke_claimed_node

    async def request_cancel(self, scope: IdempotencyScope, execution_id: str) -> bool:
        """Persist a host-authorized cancellation for worker reconciliation."""
        return await DurableJobs(self._engine).request_cancel(
            IdempotencyScope.model_validate(scope), execution_id
        )

    async def read_finalization(
        self, scope: IdempotencyScope, execution_id: str
    ) -> ExecutionFinalization | None:
        """Read the effects of committed atomic publication in the caller's scope."""
        async with self._engine.connect() as connection:
            return await repo.read_finalization(
                connection,
                IdempotencyScope.model_validate(scope),
                execution_id,
                ExecutionFinalization,
            )

    async def pending_finalizations(
        self, scope: IdempotencyScope, *, limit: int = 32
    ) -> tuple[str, ...]:
        """Find scoped Executions ready for publication during service recovery."""
        return await DurableJobs(self._engine).pending_finalizations(
            IdempotencyScope.model_validate(scope), limit=limit
        )

    async def run_next(
        self,
        scope: IdempotencyScope,
        *,
        owner: str,
        lease_ms: int,
        after_execution_id: str | None = None,
        limit: int = 32,
    ) -> WorkerPoll:
        """Advance reachable work without a remembered Execution ID.

        Continue with the returned cursor. A null cursor starts a fresh scan.
        Unavailable historical inputs are reported while other Executions proceed.
        """
        scope = IdempotencyScope.model_validate(scope)
        validated_milliseconds(lease_ms)
        if type(limit) is not int or not 1 <= limit <= 1024:
            raise ValueError("worker scan limit must be between 1 and 1024")
        async with self._engine.connect() as connection:
            candidates = await runnable_executions(
                connection, scope, after_execution_id, limit + 1
            )
        issues: list[PollIssue] = []
        page = candidates[:limit]
        for index, execution_id in enumerate(page):
            try:
                step = await self.run_once(
                    scope, execution_id, owner=owner, lease_ms=lease_ms
                )
            except WorkerSourceError as error:
                issues.append(PollIssue(execution_id, error.code, error.retryable))
                continue
            if step is not WorkerStep.IDLE:
                cursor = execution_id if index + 1 < len(candidates) else None
                return WorkerPoll(step, execution_id, cursor, tuple(issues))
        cursor = page[-1] if len(candidates) > limit else None
        return WorkerPoll(WorkerStep.IDLE, None, cursor, tuple(issues))

    async def run_once(
        self,
        scope: IdempotencyScope,
        execution_id: str,
        *,
        owner: str,
        lease_ms: int,
        after_start: AttemptCheckpoint | None = None,
    ) -> WorkerStep:
        """Claim/invoke one branch, reconcile a cancellation, or publish Coverage."""
        scope = IdempotencyScope.model_validate(scope)
        validated_milliseconds(lease_ms)
        async with self._engine.connect() as connection:
            locked = await repo.get_execution(connection, scope, execution_id)
            at = (
                await connection.execute(text("SELECT pg_catalog.clock_timestamp()"))
            ).scalar_one()
        if locked is None or locked.execution.status not in _ACTIVE:
            return WorkerStep.IDLE
        if locked.cancel_requested_at is not None:
            changed = await DurableJobs(self._engine).reconcile(scope, execution_id)
            return WorkerStep.CANCELLED if changed else WorkerStep.IDLE

        try:
            historical = None
            if self._invoke_claimed_node is not None:
                async with self._engine.connect() as connection:
                    historical = await read_historical_capabilities(
                        connection, scope, locked.execution
                    )
                if historical is None:
                    raise WorkerSourceError(
                        "worker_historical_capabilities_unavailable", retryable=False
                    )
            opened = await open_execution(
                locked,
                scope,
                self._manager,
                self._store,
                self._host,
                self._limits,
                at,
                historical=historical,
                require_historical=self._invoke_claimed_node is not None,
            )
        except WorkerSourceError:
            raise
        except (StoreBusy, IntakeHostUnavailable, OSError) as error:
            raise WorkerSourceError(
                "worker_source_unavailable", retryable=True
            ) from error
        except ExecutionPinError as error:
            retryable = error.code in {
                "tool_implementation_unavailable",
                "workflow_version_unavailable",
            }
            raise WorkerSourceError(error.code, retryable=retryable) from error
        except (IntakeAuthorizationError, ValueError) as error:
            raise WorkerSourceError("worker_source_invalid", retryable=False) from error

        async def on_terminal(
            connection: AsyncConnection,
            job_scope: IdempotencyScope,
            state: repo.LockedExecution,
            node: NodeRun,
            attempt: Attempt,
            outcome: SucceededNodeOutput | FailedNodeOutput | None,
            now: datetime,
        ) -> None:
            await schedule_after_terminal(
                connection, job_scope, opened, state.execution.execution_id, now
            )

        async def publish(
            connection: AsyncConnection,
            job_scope: IdempotencyScope,
            state: repo.LockedExecution,
            drafts: tuple[StagedDecision, ...],
            now: datetime,
        ) -> bool:
            return await finalize(connection, job_scope, state, drafts, now, opened)

        jobs = DurableJobs(self._engine, on_terminal=on_terminal)
        claim = await jobs.claim(scope, owner, lease_ms, execution_id=execution_id)
        if claim is None:
            if await jobs.finalize_staged(scope, execution_id, publish):
                return WorkerStep.FINALIZED
            return WorkerStep.IDLE
        attempt = await jobs.start(claim)
        if attempt is None:
            return WorkerStep.LEASE_LOST
        stopped = Event()
        async with TaskGroup() as tasks:
            tasks.create_task(_renew(jobs, claim, lease_ms, stopped))
            try:
                if after_start is not None:
                    await after_start(claim, attempt)
                async with self._engine.begin() as connection:
                    # Read one consistent snapshot before any adapter work.
                    await connection.execute(
                        text(
                            "SET TRANSACTION ISOLATION LEVEL REPEATABLE READ READ ONLY"
                        )
                    )
                    current = await repo.get_execution(connection, scope, execution_id)
                    if current is None or current.execution.status not in _ACTIVE:
                        return WorkerStep.LEASE_LOST
                    data = await load_records(connection, scope, current)
                (branch,) = tuple(
                    key
                    for key, node in data.runs.items()
                    if node.node_run_id == claim.node_run_id
                )
                previous, node = data.inputs(branch.object_id), data.runs[branch]
                assert attempt.started_at is not None
                attempt_deadline = attempt.started_at + timedelta(
                    milliseconds=data.locked.scheduling_limits.for_node(
                        node.node_id
                    ).timeout_ms
                )
                result: NodeResult | None
                try:
                    candidate = (
                        await self._invoke_node(opened, previous, branch, node, attempt)
                        if self._invoke_claimed_node is None
                        else await self._invoke_claimed_node(
                            ClaimedNode(
                                claim,
                                attempt,
                                node,
                                branch,
                                opened,
                                previous,
                                data.locked.execution,
                                attempt_deadline,
                            )
                        )
                    )
                    history = None
                    if isinstance(candidate.message, ToolMessage):
                        async with self._engine.connect() as connection:
                            history = await load_parent_step_history(
                                connection, claim.scope, candidate.message.inputs
                            )
                    result = check_result(
                        opened,
                        previous,
                        branch,
                        node,
                        attempt,
                        candidate,
                        tool_step_history=history,
                    )
                    failure = None
                except Exception as error:
                    failure = _failed_node(node, attempt, error)
                    result = (
                        failed_discovery(
                            opened, previous, branch, node, attempt, failure
                        )
                        if node.node_id is NodeId.N02
                        else None
                    )
            finally:
                stopped.set()
        if result is not None:
            disposition = await self._commit(jobs, claim, result)
        else:
            assert failure is not None
            disposition = await jobs.complete(claim, failure)
        return WorkerStep(disposition.value)

    @staticmethod
    async def _commit(
        jobs: DurableJobs, claim: JobClaim, result: NodeResult
    ) -> CompletionDisposition:
        async def persist(
            connection: AsyncConnection,
            scope: IdempotencyScope,
            locked: repo.LockedExecution,
            node: NodeRun,
            attempt: Attempt,
            outcome: SucceededNodeOutput | FailedNodeOutput,
            now: datetime,
        ) -> None:
            await persist_result(
                connection, scope, locked, node, attempt, outcome, now, result
            )

        response, response_record = _response(result)
        outcome = result.message.output_envelope()
        if isinstance(result.message, DecisionMessage):
            if not isinstance(outcome, SucceededNodeOutput):
                raise ValueError("staged decisions require a successful node envelope")
            return await jobs.stage_decision(
                claim,
                outcome,
                result.message.draft,
                response=response,
                response_record=response_record,
                persist=persist,
            )
        if not isinstance(outcome, (SucceededNodeOutput, FailedNodeOutput)):
            raise ValueError("offline nodes produce a success or failure envelope")
        return await jobs.complete(
            claim,
            outcome,
            response=response,
            response_record=response_record,
            persist=persist,
        )
